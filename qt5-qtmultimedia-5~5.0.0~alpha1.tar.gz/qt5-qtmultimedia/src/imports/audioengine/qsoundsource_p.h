/****************************************************************************
**
** Copyright (C) 2012 Nokia Corporation and/or its subsidiary(-ies).
** Contact: http://www.qt-project.org/
**
** This file is part of the plugins of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:LGPL$
** GNU Lesser General Public License Usage
** This file may be used under the terms of the GNU Lesser General Public
** License version 2.1 as published by the Free Software Foundation and
** appearing in the file LICENSE.LGPL included in the packaging of this
** file. Please review the following information to ensure the GNU Lesser
** General Public License version 2.1 requirements will be met:
** http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html.
**
** In addition, as a special exception, Nokia gives you certain additional
** rights. These rights are described in the Nokia Qt LGPL Exception
** version 1.1, included in the file LGPL_EXCEPTION.txt in this package.
**
** GNU General Public License Usage
** Alternatively, this file may be used under the terms of the GNU General
** Public License version 3.0 as published by the Free Software Foundation
** and appearing in the file LICENSE.GPL included in the packaging of this
** file. Please review the following information to ensure the GNU General
** Public License version 3.0 requirements will be met:
** http://www.gnu.org/copyleft/gpl.html.
**
** Other Usage
** Alternatively, this file may be used in accordance with the terms and
** conditions contained in a signed written agreement between you and Nokia.
**
**
**
**
**
**
** $QT_END_LICENSE$
**
****************************************************************************/

#ifndef QSOUNDSOURCE_P_H
#define QSOUNDSOURCE_P_H

#include <QVector3D>
#include <QObject>

QT_BEGIN_HEADER

QT_BEGIN_NAMESPACE

class QSoundBuffer;

class QSoundSource : public QObject
{
    Q_OBJECT
public:
    enum State
    {
        StoppedState,
        PlayingState,
        PausedState
    };

    virtual void play() = 0;
    virtual void pause() = 0;
    virtual void stop() = 0;

    virtual QSoundSource::State state() const = 0;

    virtual void setLooping(bool looping) = 0;
    virtual void setDirection(const QVector3D& direction) = 0;
    virtual void setPosition(const QVector3D& position) = 0;
    virtual void setVelocity(const QVector3D& velocity) = 0;

    virtual QVector3D velocity() const = 0;
    virtual QVector3D position() const = 0;
    virtual QVector3D direction() const = 0;

    virtual void setGain(qreal gain) = 0;
    virtual void setPitch(qreal pitch) = 0;
    virtual void setCone(qreal innerAngle, qreal outerAngle, qreal outerGain) = 0;

    virtual void bindBuffer(QSoundBuffer*) = 0;
    virtual void unbindBuffer() = 0;

Q_SIGNALS:
    void stateChanged(QSoundSource::State newState);

protected:
    QSoundSource(QObject *parent);
};

QT_END_NAMESPACE

QT_END_HEADER

#endif
