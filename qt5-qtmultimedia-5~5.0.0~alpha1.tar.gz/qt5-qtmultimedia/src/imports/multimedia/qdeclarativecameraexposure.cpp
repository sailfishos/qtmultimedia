/****************************************************************************
**
** Copyright (C) 2012 Nokia Corporation and/or its subsidiary(-ies).
** Contact: http://www.qt-project.org/
**
** This file is part of the plugins of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:LGPL$
** GNU Lesser General Public License Usage
** This file may be used under the terms of the GNU Lesser General Public
** License version 2.1 as published by the Free Software Foundation and
** appearing in the file LICENSE.LGPL included in the packaging of this
** file. Please review the following information to ensure the GNU Lesser
** General Public License version 2.1 requirements will be met:
** http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html.
**
** In addition, as a special exception, Nokia gives you certain additional
** rights. These rights are described in the Nokia Qt LGPL Exception
** version 1.1, included in the file LGPL_EXCEPTION.txt in this package.
**
** GNU General Public License Usage
** Alternatively, this file may be used under the terms of the GNU General
** Public License version 3.0 as published by the Free Software Foundation
** and appearing in the file LICENSE.GPL included in the packaging of this
** file. Please review the following information to ensure the GNU General
** Public License version 3.0 requirements will be met:
** http://www.gnu.org/copyleft/gpl.html.
**
** Other Usage
** Alternatively, this file may be used in accordance with the terms and
** conditions contained in a signed written agreement between you and Nokia.
**
**
**
**
**
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include "qdeclarativecamera_p.h"
#include "qdeclarativecameraexposure_p.h"

QT_BEGIN_NAMESPACE

/*!
    \qmlclass CameraExposure QDeclarativeCameraExposure
    \brief The CameraExposure element provides interface for exposure related camera settings.
    \ingroup multimedia_qml
    \ingroup camera_qml
    \inqmlmodule QtMultimedia 5

    This element is part of the \b{QtMultimedia 5.0} module.

    This element allows you to adjust exposure related settings
    like aperture and shutter speed, metering and ISO speed.

    It should not be constructed separately but provided by the
    Camera element's \l {Camera::exposure} {exposure} property.

    \qml
    import QtQuick 2.0
    import QtMultimedia 5.0

    Camera {
        id: camera

        exposure.exposureCompensation: -1.0
        exposure.exposureMode: Camera.ExposurePortrait
    }

    \endqml

    Several settings have both an automatic and a manual mode.  In
    the automatic modes the camera software itself will decide what
    a reasonable setting is, but in most cases these settings can
    be overridden with a specific manual setting.

    For example, to select automatic shutter speed selection:

    \qml
        camera.exposure.setAutoShutterSpeed()
    \endqml

    Or for a specific shutter speed:

    \qml
        camera.exposure.manualShutterSpeed = 0.01 // 10ms
    \endqml

    You can only choose one or the other mode.
*/

/*!
    \internal
    \class QDeclarativeCameraExposure
    \brief The CameraExposure element provides interface for exposure related camera settings.

*/

/*!
    Construct a declarative camera exposure object using \a parent object.
 */
QDeclarativeCameraExposure::QDeclarativeCameraExposure(QCamera *camera, QObject *parent) :
    QObject(parent)
{
    m_exposure = camera->exposure();

    connect(m_exposure, SIGNAL(isoSensitivityChanged(int)), this, SIGNAL(isoSensitivityChanged(int)));
    connect(m_exposure, SIGNAL(apertureChanged(qreal)), this, SIGNAL(apertureChanged(qreal)));
    connect(m_exposure, SIGNAL(shutterSpeedChanged(qreal)), this, SIGNAL(shutterSpeedChanged(qreal)));

    connect(m_exposure, SIGNAL(exposureCompensationChanged(qreal)), this, SIGNAL(exposureCompensationChanged(qreal)));
}

QDeclarativeCameraExposure::~QDeclarativeCameraExposure()
{
}

/*!
    \qmlproperty real QtMultimedia5::CameraExposure::exposureCompensation
    \property QDeclarativeCameraExposure::exposureCompensation

    Adjustment for the automatically calculated exposure.  The value is
    in EV units.
 */
qreal QDeclarativeCameraExposure::exposureCompensation() const
{
    return m_exposure->exposureCompensation();
}

void QDeclarativeCameraExposure::setExposureCompensation(qreal ev)
{
    m_exposure->setExposureCompensation(ev);
}

/*!
    \qmlproperty integer QtMultimedia5::CameraExposure::iso
    \property QDeclarativeCameraExposure::iso

    The sensor's ISO sensitivity.
 */
int QDeclarativeCameraExposure::isoSensitivity() const
{
    return m_exposure->isoSensitivity();
}

/*!
    \qmlproperty real QtMultimedia5::CameraExposure::shutterSpeed
    \property QDeclarativeCameraExposure::shutterSpeed

    The camera's current shutter speed setting, in seconds.  To affect
    the shutter speed you can use the \l manualShutterSpeed
    property and \l setAutoShutterSpeed().

*/
qreal QDeclarativeCameraExposure::shutterSpeed() const
{
    return m_exposure->shutterSpeed();
}

/*!
    \qmlproperty real QtMultimedia5::CameraExposure::aperture
    \property QDeclarativeCameraExposure::aperture

    The current lens aperture as an F number (the ratio of
    the focal length to effective aperture diameter).

    \sa manualAperture, setAutoAperture()
*/
qreal QDeclarativeCameraExposure::aperture() const
{
    return m_exposure->aperture();
}

/*!
    \qmlproperty integer QtMultimedia5::CameraExposure::manualIsoSensitivity
    \property QDeclarativeCameraExposure::manualIsoSensitivity

    This property allows you to set a specific ISO setting
    for image capturing.

    If a negative value is specified, the camera will
    automatically determine an appropriate value.

    \sa iso, setAutoIsoSensitivity()
*/

int QDeclarativeCameraExposure::manualIsoSensitivity() const
{
    return m_manualIso;
}

void QDeclarativeCameraExposure::setManualIsoSensitivity(int iso)
{
    m_manualIso = iso;
    if (iso > 0)
        m_exposure->setManualIsoSensitivity(iso);
    else
        m_exposure->setAutoIsoSensitivity();

    emit manualIsoSensitivityChanged(iso);
}

/*!
    \qmlproperty real QtMultimedia5::CameraExposure::manualShutterSpeed
    \property QDeclarativeCameraExposure::manualShutterSpeed

    This property allows you to set the shutter speed to
    use during capture (in seconds).  If the value is less than zero,
    then an automatic value is used and the camera will
    determine an appropriate shutter speed.

    \l shutterSpeed, setAutoShutterSpeed()
*/
qreal QDeclarativeCameraExposure::manualShutterSpeed() const
{
    return m_manualShutterSpeed;
}

void QDeclarativeCameraExposure::setManualShutterSpeed(qreal speed)
{
    m_manualShutterSpeed = speed;
    if (speed > 0)
        m_exposure->setManualShutterSpeed(speed);
    else
        m_exposure->setAutoShutterSpeed();

    emit manualShutterSpeedChanged(speed);
}

/*!
    \qmlproperty real QtMultimedia5::CameraExposure::manualAperture
    \property QDeclarativeCameraExposure::manualAperture

    This property allows you to set the aperture (F number)
    setting to use during capture.  If the value is less than zero,
    then an automatic value is used and the camera will
    determine an appropriate aperture value.

    \l aperture, setAutoAperture()
*/
qreal QDeclarativeCameraExposure::manualAperture() const
{
    return m_manualAperture;
}

void QDeclarativeCameraExposure::setManualAperture(qreal aperture)
{
    m_manualAperture = aperture;
    if (aperture > 0)
        m_exposure->setManualAperture(aperture);
    else
        m_exposure->setAutoAperture();

    emit manualApertureChanged(aperture);
}

/*!
    \qmlmethod QtMultimedia5::CameraExposure::setAutoAperture()
  Turn on auto aperture selection. The manual aperture value is reset to -1.0
 */
void QDeclarativeCameraExposure::setAutoAperture()
{
    setManualAperture(-1.0);
}

/*!
    \qmlmethod QtMultimedia5::CameraExposure::setAutoShutterSpeed()
  Turn on auto shutter speed selection. The manual shutter speed value is reset to -1.0
 */
void QDeclarativeCameraExposure::setAutoShutterSpeed()
{
    setManualShutterSpeed(-1.0);
}

/*!
    \qmlmethod QtMultimedia5::CameraExposure::setAutoIsoSensitivity()
  Turn on auto ISO sensitivity selection. The manual ISO value is reset to -1.
 */
void QDeclarativeCameraExposure::setAutoIsoSensitivity()
{
    setManualIsoSensitivity(-1);
}

/*!
    \qmlproperty enumeration QtMultimedia5::CameraExposure::exposureMode
    \property QDeclarativeCameraExposure::exposureMode

    Set the camera exposure mode to one of the following:

    \table
    \header \li Value \li Description
    \row \li Camera.ExposureManual        \li Manual mode.
    \row \li Camera.ExposureAuto          \li Automatic mode.
    \row \li Camera.ExposureNight         \li Night mode.
    \row \li Camera.ExposureBacklight     \li Backlight exposure mode.
    \row \li Camera.ExposureSpotlight     \li Spotlight exposure mode.
    \row \li Camera.ExposureSports        \li Spots exposure mode.
    \row \li Camera.ExposureSnow          \li Snow exposure mode.
    \row \li Camera.ExposureBeach         \li Beach exposure mode.
    \row \li Camera.ExposureLargeAperture \li Use larger aperture with small depth of field.
    \row \li Camera.ExposureSmallAperture \li Use smaller aperture.
    \row \li Camera.ExposurePortrait      \li Portrait exposure mode.
    \row \li Camera.ExposureModeVendor    \li The base value for device specific exposure modes.
    \endtable
*/

QDeclarativeCamera::ExposureMode QDeclarativeCameraExposure::exposureMode() const
{
    return QDeclarativeCamera::ExposureMode(m_exposure->exposureMode());
}

void QDeclarativeCameraExposure::setExposureMode(QDeclarativeCamera::ExposureMode mode)
{
    if (exposureMode() != mode) {
        m_exposure->setExposureMode(QCameraExposure::ExposureMode(mode));
        emit exposureModeChanged(exposureMode());
    }
}

/*!
    \qmlproperty QPointF QtMultimedia5::CameraExposure::spotMeteringPoint
    \property QDeclarativeCameraExposure::spotMeteringPoint

    The relative frame coordinates of the point to use for exposure metering.
    This point is only used in spot metering mode, and typically defaults
    to the center \c (0.5, 0.5).
 */

QPointF QDeclarativeCameraExposure::spotMeteringPoint() const
{
    return m_exposure->spotMeteringPoint();
}

void QDeclarativeCameraExposure::setSpotMeteringPoint(const QPointF &point)
{
    QPointF oldPoint(spotMeteringPoint());
    m_exposure->setSpotMeteringPoint(point);

    if (oldPoint != spotMeteringPoint())
        emit spotMeteringPointChanged(spotMeteringPoint());
}

/*!
    \qmlproperty enumeration QtMultimedia5::CameraExposure::meteringMode
    \property QDeclarativeCameraExposure::meteringMode

    Set the camera metering mode (how exposure is balanced)
    to one of the following:

    \table
    \header \li Value \li Description
    \row \li Camera.MeteringMatrix       \li A matrix of sample points is used to measure exposure.
    \row \li Camera.MeteringAverage      \li An average is used to measure exposure.
    \row \li Camera.MeteringSpot         \li A specific location (\l spotMeteringPoint) is used to measure exposure.
    \endtable
*/
QDeclarativeCamera::MeteringMode QDeclarativeCameraExposure::meteringMode() const
{
    return QDeclarativeCamera::MeteringMode(m_exposure->meteringMode());
}

void QDeclarativeCameraExposure::setMeteringMode(QDeclarativeCamera::MeteringMode mode)
{
    QDeclarativeCamera::MeteringMode oldMode = meteringMode();
    m_exposure->setMeteringMode(QCameraExposure::MeteringMode(mode));
    if (oldMode != meteringMode())
        emit meteringModeChanged(meteringMode());
}

QT_END_NAMESPACE

#include "moc_qdeclarativecameraexposure_p.cpp"
