/****************************************************************************
**
** Copyright (C) 2012 Nokia Corporation and/or its subsidiary(-ies).
** Contact: http://www.qt-project.org/
**
** This file is part of the plugins of the Qt Toolkit.
**
** $QT_BEGIN_LICENSE:LGPL$
** GNU Lesser General Public License Usage
** This file may be used under the terms of the GNU Lesser General Public
** License version 2.1 as published by the Free Software Foundation and
** appearing in the file LICENSE.LGPL included in the packaging of this
** file. Please review the following information to ensure the GNU Lesser
** General Public License version 2.1 requirements will be met:
** http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html.
**
** In addition, as a special exception, Nokia gives you certain additional
** rights. These rights are described in the Nokia Qt LGPL Exception
** version 1.1, included in the file LGPL_EXCEPTION.txt in this package.
**
** GNU General Public License Usage
** Alternatively, this file may be used under the terms of the GNU General
** Public License version 3.0 as published by the Free Software Foundation
** and appearing in the file LICENSE.GPL included in the packaging of this
** file. Please review the following information to ensure the GNU General
** Public License version 3.0 requirements will be met:
** http://www.gnu.org/copyleft/gpl.html.
**
** Other Usage
** Alternatively, this file may be used in accordance with the terms and
** conditions contained in a signed written agreement between you and Nokia.
**
**
**
**
**
**
** $QT_END_LICENSE$
**
****************************************************************************/

#include "qdeclarativecamera_p.h"
#include "qdeclarativecameracapture_p.h"
#include "qdeclarativecamerapreviewprovider_p.h"

#include <qmetadatawritercontrol.h>

#include <QtCore/qurl.h>

QT_BEGIN_NAMESPACE

/*!
    \qmlclass CameraCapture QDeclarativeCameraCapture
    \brief The CameraCapture element provides an interface for capturing camera images
    \ingroup multimedia_qml
    \inqmlmodule QtMultimedia 5
    \ingroup camera_qml

    This element allows you to capture still images and be notified when they
    are available or saved to disk.  You can adjust the resolution of the captured
    image and where the saved image should go.

    This element is a child of a Camera element (as the
    \l {Camera::imageCapture}{imageCapture} property) and cannot be created
    directly.

    \qml
    import QtQuick 2.0
    import QtMultimedia 5.0

    Camera {
        id: camera

        imageCapture {
            onImageCaptured: {
                // Show the preview in an Image element
                photoPreview.source = preview
            }
        }
    }

    VideoOutput {
        source: camera
        focus : visible // to receive focus and capture key events when visible

        MouseArea {
            anchors.fill: parent;
            onClicked: camera.imageCapture.capture();
        }
    }

    Image {
        id: photoPreview
    }
    \endqml

*/

QDeclarativeCameraCapture::QDeclarativeCameraCapture(QCamera *camera, QObject *parent) :
    QObject(parent),
    m_camera(camera)
{
    m_capture = new QCameraImageCapture(camera, this);

    connect(m_capture, SIGNAL(readyForCaptureChanged(bool)), this, SIGNAL(readyForCaptureChanged(bool)));
    connect(m_capture, SIGNAL(imageExposed(int)), this, SIGNAL(imageExposed(int)));
    connect(m_capture, SIGNAL(imageCaptured(int,QImage)), this, SLOT(_q_imageCaptured(int, QImage)));
    connect(m_capture, SIGNAL(imageMetadataAvailable(int,QString,QVariant)), this,
            SLOT(_q_imageMetadataAvailable(int,QString,QVariant)));
    connect(m_capture, SIGNAL(imageSaved(int,QString)), this, SLOT(_q_imageSaved(int, QString)));
    connect(m_capture, SIGNAL(error(int,QCameraImageCapture::Error,QString)),
            this, SLOT(_q_captureFailed(int,QCameraImageCapture::Error,QString)));

    QMediaService *service = camera->service();
    m_metadataWriterControl = service ? service->requestControl<QMetaDataWriterControl*>() : 0;
}

QDeclarativeCameraCapture::~QDeclarativeCameraCapture()
{
}

/*!
    \qmlproperty bool QtMultimedia5::CameraCapture::ready
    \property QDeclarativeCameraCapture::ready

    Indicates camera is ready to capture photo.

   It's permissible to call capture() while the camera is active
   regardless of isReadyForCapture property value.
   If camera is not ready to capture image immediately,
   the capture request is queued with all the related camera settings
   to be executed as soon as possible.
*/
bool QDeclarativeCameraCapture::isReadyForCapture() const
{
    return m_capture->isReadyForCapture();
}

/*!
    \qmlmethod QtMultimedia5::CameraCapture::capture()
    \fn QDeclarativeCameraCapture::capture()

    Start image capture.  The \l onImageCaptured() and \l onImageSaved() signals will
    be emitted when the capture is complete.

    The image will be captured to the default system location.

    Camera saves all the capture parameters like exposure settings or
    image processing parameters, so changes to camera paramaters after
    capture() is called do not affect previous capture requests.

    CameraCapture::capture returns the capture requestId parameter, used with
    imageExposed(), imageCaptured(), imageMetadataAvailable() and imageSaved() signals.
*/
int QDeclarativeCameraCapture::capture()
{
    return m_capture->capture();
}

/*!
    \qmlmethod QtMultimedia5::CameraCapture::captureToLocation(location)
    \fn QDeclarativeCameraCapture::captureToLocation(const QString &location)

    Start image capture to specified \a location.  The \l onImageCaptured() and \l onImageSaved() signals will
    be emitted when the capture is complete.

    CameraCapture::captureToLocation returns the capture requestId parameter, used with
    imageExposed(), imageCaptured(), imageMetadataAvailable() and imageSaved() signals.
*/
int QDeclarativeCameraCapture::captureToLocation(const QString &location)
{
    return m_capture->capture(location);
}

/*!
    \qmlmethod QtMultimedia5::CameraCapture::cancelCapture()
    \fn QDeclarativeCameraCapture::cancelCapture()

    Cancel pending image capture requests.
*/

void QDeclarativeCameraCapture::cancelCapture()
{
    m_capture->cancelCapture();
}

/*!
    \qmlproperty string QtMultimedia5::CameraCapture::capturedImagePath
    \property QDeclarativeCameraCapture::capturedImagePath

    The path to the last captured image.
*/
QString QDeclarativeCameraCapture::capturedImagePath() const
{
    return m_capturedImagePath;
}

void QDeclarativeCameraCapture::_q_imageCaptured(int id, const QImage &preview)
{
    QString previewId = QString("preview_%1").arg(id);
    QDeclarativeCameraPreviewProvider::registerPreview(previewId, preview);

    emit imageCaptured(id, QLatin1String("image://camera/")+previewId);
}

void QDeclarativeCameraCapture::_q_imageSaved(int id, const QString &fileName)
{
    m_capturedImagePath = fileName;
    emit imageSaved(id, fileName);
}

void QDeclarativeCameraCapture::_q_imageMetadataAvailable(int id, const QString &key, const QVariant &value)
{
    emit imageMetadataAvailable(id, key, value);
}


void QDeclarativeCameraCapture::_q_captureFailed(int id, QCameraImageCapture::Error error, const QString &message)
{
    Q_UNUSED(error);
    qWarning() << "QCameraImageCapture error:" << message;
    emit captureFailed(id, message);
}

/*!
    \qmlproperty size QtMultimedia5::CameraCapture::resolution
    \property QDeclarativeCameraCapture::resolution

    The resolution to capture the image at.  If empty, the system will pick
    a good size.
*/

QSize QDeclarativeCameraCapture::resolution()
{
    return m_imageSettings.resolution();
}

void QDeclarativeCameraCapture::setResolution(const QSize &captureResolution)
{
    if (captureResolution != resolution()) {
        m_imageSettings.setResolution(captureResolution);
        m_capture->setEncodingSettings(m_imageSettings);
        emit resolutionChanged(captureResolution);
    }
}

QCameraImageCapture::Error QDeclarativeCameraCapture::error() const
{
    return m_capture->error();
}


/*!
    \qmlproperty string QtMultimedia5::CameraCapture::errorString
    \property QDeclarativeCameraCapture::errorString

    The last capture related error message.
*/
QString QDeclarativeCameraCapture::errorString() const
{
    return m_capture->errorString();
}

/*!
    \qmlmethod QtMultimedia5::CameraCapture::setMetadata(key, value)
    \fn QDeclarativeCameraCapture::setMetadata(const QString &key, const QVariant &value)

    Sets a particular metadata \a key to \a value for the subsequent image captures.
*/
void QDeclarativeCameraCapture::setMetadata(const QString &key, const QVariant &value)
{
    if (m_metadataWriterControl)
        m_metadataWriterControl->setMetaData(key, value);
}

/*!
    \qmlsignal QtMultimedia5::CameraCapture::onCaptureFailed(requestId, message)
    \fn QDeclarativeCameraCapture::captureFailed(int requestId, const QString &message)

    This handler is called when an error occurs during capture with \a requestId.
    A descriptive message is available in \a message.
*/

/*!
    \qmlsignal QtMultimedia5::CameraCapture::onImageCaptured(requestId, preview)
    \fn QDeclarativeCameraCapture::imageCaptured(int requestId, const QString &preview)

    This handler is called when an image with \a requestId has been captured
    but not yet saved to the filesystem.  The \a preview
    parameter can be used as the URL supplied to an Image element.

    \sa onImageSaved
*/

/*!
    \qmlsignal QtMultimedia5::CameraCapture::onImageSaved(requestId, path)
    \fn QDeclarativeCameraCapture::imageSaved(int requestId, const QString &path)

    This handler is called after the image with \a requestId has been written to the filesystem.
    The \a path is a local file path, not a URL.

    \sa onImageCaptured
*/


/*!
    \qmlsignal QtMultimedia5::CameraCapture::onImageMetadataAvailable(requestId, key, value)
    \fn QDeclarativeCameraCapture::imageMetadataAvailable(int requestId, const QString &key, const QVariant &value);

    This handler is called when the image with \a requestId has new metadata
    available with the key \a key and value \a value.

    \sa onImageCaptured
*/


QT_END_NAMESPACE

#include "moc_qdeclarativecameracapture_p.cpp"
